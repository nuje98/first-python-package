from setuptools import setup

setup(name='anuj',
      version='1.0.0',
      description='Gaussian and Binomial distributions',
      packages=['anuj'],
      author = 'Anuj Jhamb',
      author_email = 'anuj.jhamb23@gmail.com',
      zip_safe=False)
